

function handleRedirect(select) {
    if (select.value === "Admin") {
        window.location.href = "admin_login.html";
    } 
    else if (select.value === "Users") {
        window.location.href = "log_sign_page.html";
    }
}

// Page load hone per dropdown reset hoga
window.addEventListener("load", resetDropdown);
window.addEventListener("pageshow", resetDropdown);
window.addEventListener("focus", resetDropdown);

function resetDropdown() {
    const roleDropdown = document.getElementById("role");
    if (roleDropdown) {
        roleDropdown.selectedIndex = 0; // First option select karegaa
        roleDropdown.value = "Login-Option"; // Default value set karega
    }
}