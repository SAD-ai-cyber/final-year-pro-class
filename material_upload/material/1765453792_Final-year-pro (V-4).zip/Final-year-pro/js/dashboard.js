// // State management
// let state = {
//     sidebarOpen: false,
//     activeMenu: 'dashboard',
//     isDesktop: window.innerWidth >= 1024,
//     userDropdownOpen: false,
//     notificationDropdownOpen: false,
//     isTransitioning: false // Animation ke dauraan extra clicks ko rokta hai
// };

// // DOM elements
// const elements = {
//     menuToggle: document.getElementById('menuToggle'),
//     sidebar: document.getElementById('sidebar'),
//     mainContent: document.getElementById('mainContent'),
//     overlay: document.getElementById('overlay'),
//     userBtn: document.getElementById('userBtn'),
//     userDropdown: document.getElementById('userDropdown'),
//     notificationBtn: document.getElementById('notificationBtn'),
//     notificationDropdown: document.getElementById('notificationDropdown'),
//     markAllRead: document.getElementById('markAllRead'),
//     sidebarMains: document.querySelectorAll('.sidebar-main'),
//     submenuItems: document.querySelectorAll('.submenu-item'),
//     quickActions: document.querySelectorAll('.quick-action'),
// };

// // Smooth fade transitions ke liye CSS styles add karta hai
// function injectTransitionStyles() {
//     const style = document.createElement('style');
//     style.textContent = `
//         .view-container { transition: opacity 0.2s ease-in-out, transform 0.2s ease-in-out; }
//         .fade-out { opacity: 0; transform: scale(0.98); }
//         .fade-in { opacity: 1; transform: scale(1); }
//     `;
//     document.head.appendChild(style);
// }

// // Dashboard content ko dynamically wrap karta hai aur form container banata hai
// function setupDynamicViews() {
//     const mainContent = elements.mainContent;
//     const footer = document.querySelector('.footer');
//     const dashboardView = document.createElement('div');
//     dashboardView.id = 'dashboard-view';
//     dashboardView.classList.add('view-container');
//     elements.dashboardView = dashboardView;
//     const dashboardComponents = ['.dashboard-header', '.stats-grid', '.quick-actions', '.notifications-card', '.activity-card'];
//     dashboardComponents.forEach(selector => {
//         const component = mainContent.querySelector(selector);
//         if (component) dashboardView.appendChild(component);
//     });
//     const formView = document.createElement('div');
//     formView.id = 'form-view';
//     formView.classList.add('view-container');
//     formView.style.display = 'none';
//     elements.formView = formView;
//     if (footer) {
//         mainContent.insertBefore(dashboardView, footer);
//         mainContent.insertBefore(formView, footer);
//     } else {
//         mainContent.appendChild(dashboardView);
//         mainContent.appendChild(formView);
//     }
// }

// // Initialize
// function init() {
//     injectTransitionStyles();
//     setupDynamicViews();
//     checkScreenSize();
//     bindEvents();
//     setActiveMenuItem();
//     updateContent('dashboard');
//     requestAnimationFrame(() => {
//         document.body.style.opacity = '1';
//     });
// }

// // Event bindings
// function bindEvents() {
//     elements.menuToggle.addEventListener('click', toggleSidebar);
//     elements.overlay.addEventListener('click', closeSidebar);
//     elements.userBtn.addEventListener('click', toggleUserDropdown);
//     elements.notificationBtn.addEventListener('click', toggleNotificationDropdown);
//     elements.markAllRead.addEventListener('click', handleMarkAllRead);
//     elements.sidebarMains.forEach(item => item.addEventListener('click', handleSidebarClick));
//     elements.submenuItems.forEach(item => item.addEventListener('click', handleSubmenuClick));
//     elements.quickActions.forEach(action => action.addEventListener('click', handleQuickAction));
//     let resizeTimeout;
//     window.addEventListener('resize', () => {
//         clearTimeout(resizeTimeout);
//         resizeTimeout = setTimeout(checkScreenSize, 100);
//     });
//     document.addEventListener('click', (e) => {
//         if (!elements.userBtn.contains(e.target) && !elements.userDropdown.contains(e.target)) closeUserDropdown();
//         if (!elements.notificationBtn.contains(e.target) && !elements.notificationDropdown.contains(e.target)) closeNotificationDropdown();
//     });
//     document.addEventListener('keydown', handleKeydown);
// }


// // ============== YAHAN BADE BADLAV KIYE GAYE HAIN ==============

// /**
//  * Naya function jo alag-alag folders se form load karta hai.
//  * @param {string} pageName - Load karne wale form ka naam.
//  */
// async function loadForm(pageName) {
//     let formPath;

//     // YEH NAYI LOGIC HAI:
//     // Agar page ka naam 'show-' se shuru hota hai, to 'show-details' folder se load karo.
//     if (pageName.startsWith('show-')) {
//         formPath = `../show-details/${pageName}.html`;
//     } else {
//         // Varna, purane 'forms' folder se load karo.
//         formPath = `../forms/${pageName}.html`;
//     }

//     console.log("Loading form from path:", formPath); // Debugging ke liye

//     elements.formView.innerHTML = `<p style="padding: 20px; text-align: center;">Loading...</p>`;
//     try {
//         const response = await fetch(formPath);
//         if (!response.ok) throw new Error(`File not found at ${formPath}`);
//         // Pehle content ko memory me load karo
//         const html = await response.text();
//         // Phir use container me daalo
//         elements.formView.innerHTML = html;
//     } catch (error) {
//         console.error('loadForm Error:', error);
//         elements.formView.innerHTML = `<div style="padding:20px;text-align:center;color:red;"><p><b>Content could not be loaded.</b></p><p>Path tried: ${formPath}</p></div>`;
//     }
// }


// /**
//  * Smooth transition ke liye update kiya gaya function.
//  * @param {string} page - Dikhane wale page ka naam.
//  */
// async function updateContent(page) {
//     if (state.isTransitioning) return;
//     state.isTransitioning = true;

//     const activeView = (elements.dashboardView.style.display !== 'none') ? elements.dashboardView : elements.formView;
//     const newView = (page === 'dashboard') ? elements.dashboardView : elements.formView;

//     // 1. Purane view ko fade-out karo
//     activeView.classList.add('fade-out');

//     // 2. Animation poora hone ka intezar karo
//     setTimeout(async () => {
//         activeView.style.display = 'none';
        
//         // 3. Naya content background me load karo
//         if (page !== 'dashboard') {
//             await loadForm(page);
//         }

//         // 4. Title aur breadcrumb update karo
//         // Is list me naye pages ke titles bhi jode ja sakte hain
//         const titles = { 'show-teacher': 'View Teachers', 'show-student': 'View Students', 'show-parent': 'View Parents', /* ... baaki purane titles */ };
//         const title = (page === 'dashboard') ? 'Dashboard' : (titles[page] || page.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()));
//         document.querySelector('.dashboard-title').textContent = title;
//         document.querySelector('.breadcrumb').innerHTML = `<a href="#">Admin</a> / ${title}`;
        
//         // 5. Naye view ko dikhao aur fade-in karo
//         newView.classList.remove('fade-out'); // Agar pehle se laga ho to hatao
//         newView.style.display = 'block';
        
//         requestAnimationFrame(() => {
//             newView.classList.add('fade-in');
//         });

//         state.isTransitioning = false;
//     }, 200); // Yah samay CSS transition se match hona chahiye
// }

// // Doosre pages se is function ko call karne ke liye ise global banaya gaya hai
// window.navigateTo = updateContent;


// // =================================================================

// // Baaki sabhi functions jaise the waise hi hain
// function checkScreenSize(){const wasDesktop=state.isDesktop;state.isDesktop=window.innerWidth>=1024;if(state.isDesktop!==wasDesktop){if(state.isDesktop){elements.sidebar.classList.add('desktop-open');elements.mainContent.classList.add('desktop-shifted');elements.overlay.classList.remove('active');state.sidebarOpen=true;}else{elements.sidebar.classList.remove('desktop-open');elements.mainContent.classList.remove('desktop-shifted');closeSidebar();}}}
// function toggleSidebar(){if(state.isDesktop){state.sidebarOpen=!state.sidebarOpen;elements.sidebar.classList.toggle('desktop-open',state.sidebarOpen);elements.mainContent.classList.toggle('desktop-shifted',state.sidebarOpen);}else{state.sidebarOpen=!state.sidebarOpen;elements.sidebar.classList.toggle('active',state.sidebarOpen);elements.overlay.classList.toggle('active',state.sidebarOpen);document.body.style.overflow=state.sidebarOpen?'hidden':'';}}
// function closeSidebar(){if(!state.isDesktop&&state.sidebarOpen){state.sidebarOpen=false;elements.sidebar.classList.remove('active');elements.overlay.classList.remove('active');document.body.style.overflow='';}}
// function toggleUserDropdown(e){e.stopPropagation();state.userDropdownOpen=!state.userDropdownOpen;elements.userDropdown.classList.toggle('active',state.userDropdownOpen);if(state.notificationDropdownOpen)closeNotificationDropdown();}
// function closeUserDropdown(){state.userDropdownOpen=false;elements.userDropdown.classList.remove('active');}
// function toggleNotificationDropdown(e){e.stopPropagation();state.notificationDropdownOpen=!state.notificationDropdownOpen;elements.notificationDropdown.classList.toggle('active',state.notificationDropdownOpen);if(state.userDropdownOpen)closeUserDropdown();}
// function closeNotificationDropdown(){state.notificationDropdownOpen=false;elements.notificationDropdown.classList.remove('active');}
// function handleMarkAllRead(e){e.preventDefault();e.stopPropagation();const badge=document.querySelector('.notification-badge');badge.textContent='0';badge.style.display='none';showToast('All notifications marked as read','success');}
// function handleSidebarClick(e){const menuItem=e.currentTarget;const menuName=menuItem.dataset.menu;const submenu=menuItem.parentElement.querySelector('.sidebar-submenu');if(submenu){e.preventDefault();const isActive=submenu.classList.contains('active');document.querySelectorAll('.sidebar-submenu.active').forEach(menu=>{if(menu!==submenu){menu.classList.remove('active');menu.parentElement.querySelector('.sidebar-arrow')?.classList.remove('rotated');menu.parentElement.querySelector('.sidebar-main').classList.remove('active');}});submenu.classList.toggle('active',!isActive);menuItem.querySelector('.sidebar-arrow')?.classList.toggle('rotated',!isActive);menuItem.classList.toggle('active',!isActive);if(!isActive)state.activeMenu=menuName;}else{setActiveMenu(menuName);updateContent(menuName);if(!state.isDesktop)closeSidebar();}}
// function handleSubmenuClick(e){const item=e.currentTarget;const page=item.dataset.page;elements.submenuItems.forEach(submenuItem=>submenuItem.classList.remove('active'));item.classList.add('active');updateContent(page);if(!state.isDesktop)setTimeout(closeSidebar,300);}
// function setActiveMenu(menuName){elements.sidebarMains.forEach(main=>main.classList.remove('active'));const activeMain=document.querySelector(`.sidebar-main[data-menu="${menuName}"]`);if(activeMain){activeMain.classList.add('active');const parentItem=activeMain.closest('.sidebar-item');const submenu=parentItem.querySelector('.sidebar-submenu');if(submenu){submenu.classList.add('active');activeMain.querySelector('.sidebar-arrow')?.classList.add('rotated');}}}
// function setActiveMenuItem(){setActiveMenu('dashboard');}
// function handleQuickAction(e){const action=e.currentTarget.dataset.action;e.currentTarget.style.transform='scale(0.95)';setTimeout(()=>{e.currentTarget.style.transform='';},150);const actionMap={'add-student':'student-add','create-exam':'examinationform','manage-fees':'student-fee-add'};const page=actionMap[action];if(page){updateContent(page);const targetSubmenuItem=document.querySelector(`.submenu-item[data-page="${page}"]`);if(targetSubmenuItem){const parentMenu=targetSubmenuItem.closest('.sidebar-item').querySelector('.sidebar-main').dataset.menu;setActiveMenu(parentMenu);}}else if(action==='view-reports'){showToast('Opening Reports...','info');}}
// function handleKeydown(e){if(e.key==='Escape'){closeSidebar();closeUserDropdown();closeNotificationDropdown();}if(e.altKey&&e.key==='m'){e.preventDefault();toggleSidebar();}}
// function showToast(message,type='info'){const existingToast=document.querySelector('.toast');if(existingToast)existingToast.remove();const toast=document.createElement('div');toast.className=`toast toast-${type}`;const bgColor=type==='success'?'#28a745':type==='error'?'#dc3545':'#17a2b8';toast.style.cssText=`position: fixed; top: 90px; right: 20px; background: ${bgColor}; color: white; padding: 1rem 1.5rem; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); z-index: 10000; transform: translateX(120%); transition: transform 0.4s ease; max-width: 300px; font-size: 0.9rem;`;toast.textContent=message;document.body.appendChild(toast);requestAnimationFrame(()=>{toast.style.transform='translateX(0)';});setTimeout(()=>{toast.style.transform='translateX(120%)';toast.addEventListener('transitionend',()=>toast.remove());},3000);}

// if (document.readyState === 'loading') {
//     document.addEventListener('DOMContentLoaded', init);
// } else {
//     init();
// }
// document.querySelectorAll('.quick-action, .user-btn, .menu-toggle, .notification-btn').forEach(btn => btn.addEventListener('click', (e) => {/* Ripple effect can be added here */}));
// console.log('Class Management Dashboard initialized successfully!');















//State management
let state = {
    sidebarOpen: false,
    activeMenu: 'dashboard',
    isDesktop: window.innerWidth >= 1024,
    userDropdownOpen: false,
    notificationDropdownOpen: false,
    isTransitioning: false
};

// DOM elements
const elements = {
    menuToggle: document.getElementById('menuToggle'),
    sidebar: document.getElementById('sidebar'),
    mainContent: document.getElementById('mainContent'),
    overlay: document.getElementById('overlay'),
    userBtn: document.getElementById('userBtn'),
    userDropdown: document.getElementById('userDropdown'),
    notificationBtn: document.getElementById('notificationBtn'),
    notificationDropdown: document.getElementById('notificationDropdown'),
    markAllRead: document.getElementById('markAllRead'),
    sidebarMains: document.querySelectorAll('.sidebar-main'),
    submenuItems: document.querySelectorAll('.submenu-item'),
    quickActions: document.querySelectorAll('.quick-action'),
};

// Smooth fade transitions ke liye CSS styles add karta hai
function injectTransitionStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .view-container { transition: opacity 0.2s ease-in-out, transform 0.2s ease-in-out; }
        .fade-out { opacity: 0; transform: scale(0.98); }
        .fade-in { opacity: 1; transform: scale(1); }
    `;
    document.head.appendChild(style);
}

// Dashboard content ko dynamically wrap karta hai aur form container banata hai
function setupDynamicViews() {
    const mainContent = elements.mainContent;
    const footer = document.querySelector('.footer');
    const dashboardView = document.createElement('div');
    dashboardView.id = 'dashboard-view';
    dashboardView.classList.add('view-container');
    elements.dashboardView = dashboardView;
    const dashboardComponents = ['.dashboard-header', '.stats-grid', '.quick-actions', '.notifications-card', '.activity-card'];
    dashboardComponents.forEach(selector => {
        const component = mainContent.querySelector(selector);
        if (component) dashboardView.appendChild(component);
    });
    const formView = document.createElement('div');
    formView.id = 'form-view';
    formView.classList.add('view-container');
    formView.style.display = 'none';
    elements.formView = formView;
    if (footer) {
        mainContent.insertBefore(dashboardView, footer);
        mainContent.insertBefore(formView, footer);
    } else {
        mainContent.appendChild(dashboardView);
        mainContent.appendChild(formView);
    }
}

// Initialize
function init() {
    injectTransitionStyles();
    setupDynamicViews();
    checkScreenSize();
    bindEvents();
    setActiveMenuItem();
    updateContent('dashboard');
    requestAnimationFrame(() => {
        document.body.style.opacity = '1';
    });
}

// Event bindings
function bindEvents() {
    elements.menuToggle.addEventListener('click', toggleSidebar);
    elements.overlay.addEventListener('click', closeSidebar);
    elements.userBtn.addEventListener('click', toggleUserDropdown);
    elements.notificationBtn.addEventListener('click', toggleNotificationDropdown);
    elements.markAllRead.addEventListener('click', handleMarkAllRead);
    elements.sidebarMains.forEach(item => item.addEventListener('click', handleSidebarClick));
    elements.submenuItems.forEach(item => item.addEventListener('click', handleSubmenuClick));
    elements.quickActions.forEach(action => action.addEventListener('click', handleQuickAction));
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(checkScreenSize, 100);
    });
    document.addEventListener('click', (e) => {
        if (!elements.userBtn.contains(e.target) && !elements.userDropdown.contains(e.target)) closeUserDropdown();
        if (!elements.notificationBtn.contains(e.target) && !elements.notificationDropdown.contains(e.target)) closeNotificationDropdown();
    });
    document.addEventListener('keydown', handleKeydown);
}


// ============== YAHAN BADE BADLAV KIYE GAYE HAIN ==============

// Page se user ka role (admin/user) pata karta hai.
function getUserRole() {
    const logoSpan = document.querySelector('.logo span');
    if (logoSpan && logoSpan.textContent.trim().toLowerCase() === 'admin') {
        return 'admin';
    }
    return 'user';
}

// UPDATE KIYA GAYA FUNCTION: Ab yeh page ke andar ke scripts ko bhi chalaata hai.
async function loadForm(pageName) {
    let formPath;
    if (pageName.startsWith('show-')) {
        formPath = `../show-details/${pageName}.html`;
    } else {
        formPath = `../forms/${pageName}.html`;
    }

    elements.formView.innerHTML = `<p style="padding: 20px; text-align: center;">Loading...</p>`;
    try {
        const response = await fetch(formPath);
        if (!response.ok) throw new Error(`File not found at ${formPath}`);
        
        const html = await response.text();
        const tempContainer = document.createElement('div');
        tempContainer.innerHTML = html;

        const userRole = getUserRole();
        if (userRole !== 'admin' && pageName.startsWith('show-')) {
            tempContainer.querySelectorAll('.action-buttons').forEach(buttons => buttons.remove());
            tempContainer.querySelectorAll('thead th:last-child').forEach(th => {
                if (th.textContent.trim().toLowerCase() === 'actions') {
                    th.remove();
                }
            });
        }
        
        elements.formView.innerHTML = tempContainer.innerHTML;

        // -- YEH NAYI LOGIC HAI --
        // Load hue HTML me se script tags ko dhoond kar chalao
        const scripts = elements.formView.querySelectorAll('script');
        scripts.forEach(script => {
            const newScript = document.createElement('script');
            newScript.textContent = script.textContent;
            document.body.appendChild(newScript).remove(); 
        });
        // -- NAYI LOGIC KHATAM --

    } catch (error) {
        console.error('loadForm Error:', error);
        elements.formView.innerHTML = `<div style="padding:20px;text-align:center;color:red;"><p><b>Content could not be loaded.</b></p><p>Path tried: ${formPath}</p></div>`;
    }
}


// Smooth transition ke liye update kiya gaya function.
async function updateContent(page) {
    if (state.isTransitioning) return;
    state.isTransitioning = true;

    const activeView = (elements.dashboardView.style.display !== 'none') ? elements.dashboardView : elements.formView;
    const newView = (page === 'dashboard') ? elements.dashboardView : elements.formView;

    activeView.classList.add('fade-out');
    setTimeout(async () => {
        activeView.style.display = 'none';
        if (page !== 'dashboard') {
            await loadForm(page);
        }
        const titles = { 'show-teacher': 'View Teachers', 'show-student': 'View Students', 'show-parent': 'View Parents' };
        const title = (page === 'dashboard') ? 'Dashboard' : (titles[page] || page.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()));
        document.querySelector('.dashboard-title').textContent = title;
        document.querySelector('.breadcrumb').innerHTML = `<a href="#">Admin</a> / ${title}`;
        newView.classList.remove('fade-out');
        newView.style.display = 'block';
        requestAnimationFrame(() => { newView.classList.add('fade-in'); });
        state.isTransitioning = false;
    }, 200);
}

window.navigateTo = updateContent;

// =================================================================

// Baaki sabhi functions jaise the waise hi hain
function checkScreenSize(){const wasDesktop=state.isDesktop;state.isDesktop=window.innerWidth>=1024;if(state.isDesktop!==wasDesktop){if(state.isDesktop){elements.sidebar.classList.add('desktop-open');elements.mainContent.classList.add('desktop-shifted');elements.overlay.classList.remove('active');state.sidebarOpen=true;}else{elements.sidebar.classList.remove('desktop-open');elements.mainContent.classList.remove('desktop-shifted');closeSidebar();}}}
function toggleSidebar(){if(state.isDesktop){state.sidebarOpen=!state.sidebarOpen;elements.sidebar.classList.toggle('desktop-open',state.sidebarOpen);elements.mainContent.classList.toggle('desktop-shifted',state.sidebarOpen);}else{state.sidebarOpen=!state.sidebarOpen;elements.sidebar.classList.toggle('active',state.sidebarOpen);elements.overlay.classList.toggle('active',state.sidebarOpen);document.body.style.overflow=state.sidebarOpen?'hidden':'';}}
function closeSidebar(){if(!state.isDesktop&&state.sidebarOpen){state.sidebarOpen=false;elements.sidebar.classList.remove('active');elements.overlay.classList.remove('active');document.body.style.overflow='';}}
function toggleUserDropdown(e){e.stopPropagation();state.userDropdownOpen=!state.userDropdownOpen;elements.userDropdown.classList.toggle('active',state.userDropdownOpen);if(state.notificationDropdownOpen)closeNotificationDropdown();}
function closeUserDropdown(){state.userDropdownOpen=false;elements.userDropdown.classList.remove('active');}
function toggleNotificationDropdown(e){e.stopPropagation();state.notificationDropdownOpen=!state.notificationDropdownOpen;elements.notificationDropdown.classList.toggle('active',state.notificationDropdownOpen);if(state.userDropdownOpen)closeUserDropdown();}
function closeNotificationDropdown(){state.notificationDropdownOpen=false;elements.notificationDropdown.classList.remove('active');}
function handleMarkAllRead(e){e.preventDefault();e.stopPropagation();const badge=document.querySelector('.notification-badge');badge.textContent='0';badge.style.display='none';showToast('All notifications marked as read','success');}
function handleSidebarClick(e){const menuItem=e.currentTarget;const menuName=menuItem.dataset.menu;const submenu=menuItem.parentElement.querySelector('.sidebar-submenu');if(submenu){e.preventDefault();const isActive=submenu.classList.contains('active');document.querySelectorAll('.sidebar-submenu.active').forEach(menu=>{if(menu!==submenu){menu.classList.remove('active');menu.parentElement.querySelector('.sidebar-arrow')?.classList.remove('rotated');menu.parentElement.querySelector('.sidebar-main').classList.remove('active');}});submenu.classList.toggle('active',!isActive);menuItem.querySelector('.sidebar-arrow')?.classList.toggle('rotated',!isActive);menuItem.classList.toggle('active',!isActive);if(!isActive)state.activeMenu=menuName;}else{setActiveMenu(menuName);updateContent(menuName);if(!state.isDesktop)closeSidebar();}}
function handleSubmenuClick(e){const item=e.currentTarget;const page=item.dataset.page;elements.submenuItems.forEach(submenuItem=>submenuItem.classList.remove('active'));item.classList.add('active');updateContent(page);if(!state.isDesktop)setTimeout(closeSidebar,300);}
function setActiveMenu(menuName){elements.sidebarMains.forEach(main=>main.classList.remove('active'));const activeMain=document.querySelector(`.sidebar-main[data-menu="${menuName}"]`);if(activeMain){activeMain.classList.add('active');const parentItem=activeMain.closest('.sidebar-item');const submenu=parentItem.querySelector('.sidebar-submenu');if(submenu){submenu.classList.add('active');activeMain.querySelector('.sidebar-arrow')?.classList.add('rotated');}}}
function setActiveMenuItem(){setActiveMenu('dashboard');}
function handleQuickAction(e){const action=e.currentTarget.dataset.action;e.currentTarget.style.transform='scale(0.95)';setTimeout(()=>{e.currentTarget.style.transform='';},150);const actionMap={'add-student':'student-add','create-exam':'examinationform','manage-fees':'student-fee-add'};const page=actionMap[action];if(page){updateContent(page);const targetSubmenuItem=document.querySelector(`.submenu-item[data-page="${page}"]`);if(targetSubmenuItem){const parentMenu=targetSubmenuItem.closest('.sidebar-item').querySelector('.sidebar-main').dataset.menu;setActiveMenu(parentMenu);}}else if(action==='view-reports'){showToast('Opening Reports...','info');}}
function handleKeydown(e){if(e.key==='Escape'){closeSidebar();closeUserDropdown();closeNotificationDropdown();}if(e.altKey&&e.key==='m'){e.preventDefault();toggleSidebar();}}
function showToast(message,type='info'){const existingToast=document.querySelector('.toast');if(existingToast)existingToast.remove();const toast=document.createElement('div');toast.className=`toast toast-${type}`;const bgColor=type==='success'?'#28a745':type==='error'?'#dc3545':'#17a2b8';toast.style.cssText=`position: fixed; top: 90px; right: 20px; background: ${bgColor}; color: white; padding: 1rem 1.5rem; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); z-index: 10000; transform: translateX(120%); transition: transform 0.4s ease; max-width: 300px; font-size: 0.9rem;`;toast.textContent=message;document.body.appendChild(toast);requestAnimationFrame(()=>{toast.style.transform='translateX(0)';});setTimeout(()=>{toast.style.transform='translateX(120%)';toast.addEventListener('transitionend',()=>toast.remove());},3000);}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
document.querySelectorAll('.quick-action, .user-btn, .menu-toggle, .notification-btn').forEach(btn => btn.addEventListener('click', (e) => {/* Ripple effect can be added here */}));
console.log('Class Management Dashboard initialized successfully!');


// ye code delete button ka he jo work kar raha he

// Smooth fade transitions ke liye CSS styles add karta hai
function injectTransitionStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .view-container { transition: opacity 0.2s ease-in-out, transform 0.2s ease-in-out; }
        .fade-out { opacity: 0; transform: scale(0.98); }
        .fade-in { opacity: 1; transform: scale(1); }
    `;
    document.head.appendChild(style);
}

// Dashboard content ko dynamically wrap karta hai aur form container banata hai
function setupDynamicViews() {
    const mainContent = elements.mainContent;
    const footer = document.querySelector('.footer');
    const dashboardView = document.createElement('div');
    dashboardView.id = 'dashboard-view';
    dashboardView.classList.add('view-container');
    elements.dashboardView = dashboardView;
    const dashboardComponents = ['.dashboard-header', '.stats-grid', '.quick-actions', '.notifications-card', '.activity-card'];
    dashboardComponents.forEach(selector => {
        const component = mainContent.querySelector(selector);
        if (component) dashboardView.appendChild(component);
    });
    const formView = document.createElement('div');
    formView.id = 'form-view';
    formView.classList.add('view-container');
    formView.style.display = 'none';
    elements.formView = formView;
    if (footer) {
        mainContent.insertBefore(dashboardView, footer);
        mainContent.insertBefore(formView, footer);
    } else {
        mainContent.appendChild(dashboardView);
        mainContent.appendChild(formView);
    }
}

// Initialize
function init() {
    injectTransitionStyles();
    setupDynamicViews();
    checkScreenSize();
    bindEvents();
    setActiveMenuItem();
    updateContent('dashboard');
    requestAnimationFrame(() => {
        document.body.style.opacity = '1';
    });
}

// Event bindings
function bindEvents() {
    elements.menuToggle.addEventListener('click', toggleSidebar);
    elements.overlay.addEventListener('click', closeSidebar);
    elements.userBtn.addEventListener('click', toggleUserDropdown);
    elements.notificationBtn.addEventListener('click', toggleNotificationDropdown);
    elements.markAllRead.addEventListener('click', handleMarkAllRead);
    elements.sidebarMains.forEach(item => item.addEventListener('click', handleSidebarClick));
    elements.submenuItems.forEach(item => item.addEventListener('click', handleSubmenuClick));
    elements.quickActions.forEach(action => action.addEventListener('click', handleQuickAction));
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(checkScreenSize, 100);
    });
    document.addEventListener('click', (e) => {
        if (!elements.userBtn.contains(e.target) && !elements.userDropdown.contains(e.target)) closeUserDropdown();
        if (!elements.notificationBtn.contains(e.target) && !elements.notificationDropdown.contains(e.target)) closeNotificationDropdown();
    });
    document.addEventListener('keydown', handleKeydown);
}

// Page se user ka role (admin/user) pata karta hai.
function getUserRole() {
    const logoSpan = document.querySelector('.logo span');
    if (logoSpan && logoSpan.textContent.trim().toLowerCase() === 'admin') {
        return 'admin';
    }
    return 'user';
}

// UPDATE KIYA GAYA FUNCTION: Ab yeh page ke andar ke scripts ko bhi chalaata hai.
async function loadForm(pageName) {
    let formPath;
    if (pageName.startsWith('show-')) {
        formPath = `../show-details/${pageName}.html`;
    } else {
        formPath = `../forms/${pageName}.html`;
    }

    elements.formView.innerHTML = `<p style="padding: 20px; text-align: center;">Loading...</p>`;
    try {
        const response = await fetch(formPath);
        if (!response.ok) throw new Error(`File not found at ${formPath}`);
        
        const html = await response.text();
        const tempContainer = document.createElement('div');
        tempContainer.innerHTML = html;

        const userRole = getUserRole();
        if (userRole !== 'admin' && pageName.startsWith('show-')) {
            tempContainer.querySelectorAll('.action-buttons').forEach(buttons => buttons.remove());
            tempContainer.querySelectorAll('thead th:last-child').forEach(th => {
                if (th.textContent.trim().toLowerCase() === 'actions') {
                    th.remove();
                }
            });
        }
        
        elements.formView.innerHTML = tempContainer.innerHTML;

        // -- YEH NAYI LOGIC HAI --
        // Load hue HTML me se script tags ko dhoond kar chalao
        const scripts = elements.formView.querySelectorAll('script');
        scripts.forEach(script => {
            const newScript = document.createElement('script');
            newScript.textContent = script.textContent;
            document.body.appendChild(newScript).remove(); 
        });
        // -- NAYI LOGIC KHATAM --

    } catch (error) {
        console.error('loadForm Error:', error);
        elements.formView.innerHTML = `<div style="padding:20px;text-align:center;color:red;"><p><b>Content could not be loaded.</b></p><p>Path tried: ${formPath}</p></div>`;
    }
}


// Smooth transition ke liye update kiya gaya function.
async function updateContent(page) {
    if (state.isTransitioning) return;
    state.isTransitioning = true;

    const activeView = (elements.dashboardView.style.display !== 'none') ? elements.dashboardView : elements.formView;
    const newView = (page === 'dashboard') ? elements.dashboardView : elements.formView;

    activeView.classList.add('fade-out');
    setTimeout(async () => {
        activeView.style.display = 'none';
        if (page !== 'dashboard') {
            await loadForm(page);
        }
        const titles = { 'show-teacher': 'View Teachers', 'show-student': 'View Students', 'show-parent': 'View Parents' };
        const title = (page === 'dashboard') ? 'Dashboard' : (titles[page] || page.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()));
        document.querySelector('.dashboard-title').textContent = title;
        document.querySelector('.breadcrumb').innerHTML = `<a href="#">Admin</a> / ${title}`;
        newView.classList.remove('fade-out');
        newView.style.display = 'block';
        requestAnimationFrame(() => { newView.classList.add('fade-in'); });
        state.isTransitioning = false;
    }, 200);
}

window.navigateTo = updateContent;

// =================================================================

// Baaki sabhi functions jaise the waise hi hain
function checkScreenSize(){const wasDesktop=state.isDesktop;state.isDesktop=window.innerWidth>=1024;if(state.isDesktop!==wasDesktop){if(state.isDesktop){elements.sidebar.classList.add('desktop-open');elements.mainContent.classList.add('desktop-shifted');elements.overlay.classList.remove('active');state.sidebarOpen=true;}else{elements.sidebar.classList.remove('desktop-open');elements.mainContent.classList.remove('desktop-shifted');closeSidebar();}}}
function toggleSidebar(){if(state.isDesktop){state.sidebarOpen=!state.sidebarOpen;elements.sidebar.classList.toggle('desktop-open',state.sidebarOpen);elements.mainContent.classList.toggle('desktop-shifted',state.sidebarOpen);}else{state.sidebarOpen=!state.sidebarOpen;elements.sidebar.classList.toggle('active',state.sidebarOpen);elements.overlay.classList.toggle('active',state.sidebarOpen);document.body.style.overflow=state.sidebarOpen?'hidden':'';}}
function closeSidebar(){if(!state.isDesktop&&state.sidebarOpen){state.sidebarOpen=false;elements.sidebar.classList.remove('active');elements.overlay.classList.remove('active');document.body.style.overflow='';}}
function toggleUserDropdown(e){e.stopPropagation();state.userDropdownOpen=!state.userDropdownOpen;elements.userDropdown.classList.toggle('active',state.userDropdownOpen);if(state.notificationDropdownOpen)closeNotificationDropdown();}
function closeUserDropdown(){state.userDropdownOpen=false;elements.userDropdown.classList.remove('active');}
function toggleNotificationDropdown(e){e.stopPropagation();state.notificationDropdownOpen=!state.notificationDropdownOpen;elements.notificationDropdown.classList.toggle('active',state.notificationDropdownOpen);if(state.userDropdownOpen)closeUserDropdown();}
function closeNotificationDropdown(){state.notificationDropdownOpen=false;elements.notificationDropdown.classList.remove('active');}
function handleMarkAllRead(e){e.preventDefault();e.stopPropagation();const badge=document.querySelector('.notification-badge');badge.textContent='0';badge.style.display='none';showToast('All notifications marked as read','success');}
function handleSidebarClick(e){const menuItem=e.currentTarget;const menuName=menuItem.dataset.menu;const submenu=menuItem.parentElement.querySelector('.sidebar-submenu');if(submenu){e.preventDefault();const isActive=submenu.classList.contains('active');document.querySelectorAll('.sidebar-submenu.active').forEach(menu=>{if(menu!==submenu){menu.classList.remove('active');menu.parentElement.querySelector('.sidebar-arrow')?.classList.remove('rotated');menu.parentElement.querySelector('.sidebar-main').classList.remove('active');}});submenu.classList.toggle('active',!isActive);menuItem.querySelector('.sidebar-arrow')?.classList.toggle('rotated',!isActive);menuItem.classList.toggle('active',!isActive);if(!isActive)state.activeMenu=menuName;}else{setActiveMenu(menuName);updateContent(menuName);if(!state.isDesktop)closeSidebar();}}
function handleSubmenuClick(e){const item=e.currentTarget;const page=item.dataset.page;elements.submenuItems.forEach(submenuItem=>submenuItem.classList.remove('active'));item.classList.add('active');updateContent(page);if(!state.isDesktop)setTimeout(closeSidebar,300);}
function setActiveMenu(menuName){elements.sidebarMains.forEach(main=>main.classList.remove('active'));const activeMain=document.querySelector(`.sidebar-main[data-menu="${menuName}"]`);if(activeMain){activeMain.classList.add('active');const parentItem=activeMain.closest('.sidebar-item');const submenu=parentItem.querySelector('.sidebar-submenu');if(submenu){submenu.classList.add('active');activeMain.querySelector('.sidebar-arrow')?.classList.add('rotated');}}}
function setActiveMenuItem(){setActiveMenu('dashboard');}
function handleQuickAction(e){const action=e.currentTarget.dataset.action;e.currentTarget.style.transform='scale(0.95)';setTimeout(()=>{e.currentTarget.style.transform='';},150);const actionMap={'add-student':'student-add','create-exam':'examinationform','manage-fees':'student-fee-add'};const page=actionMap[action];if(page){updateContent(page);const targetSubmenuItem=document.querySelector(`.submenu-item[data-page="${page}"]`);if(targetSubmenuItem){const parentMenu=targetSubmenuItem.closest('.sidebar-item').querySelector('.sidebar-main').dataset.menu;setActiveMenu(parentMenu);}}else if(action==='view-reports'){showToast('Opening Reports...','info');}}
function handleKeydown(e){if(e.key==='Escape'){closeSidebar();closeUserDropdown();closeNotificationDropdown();}if(e.altKey&&e.key==='m'){e.preventDefault();toggleSidebar();}}
function showToast(message,type='info'){const existingToast=document.querySelector('.toast');if(existingToast)existingToast.remove();const toast=document.createElement('div');toast.className=`toast toast-${type}`;const bgColor=type==='success'?'#28a745':type==='error'?'#dc3545':'#17a2b8';toast.style.cssText=`position: fixed; top: 90px; right: 20px; background: ${bgColor}; color: white; padding: 1rem 1.5rem; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); z-index: 10000; transform: translateX(120%); transition: transform 0.4s ease; max-width: 300px; font-size: 0.9rem;`;toast.textContent=message;document.body.appendChild(toast);requestAnimationFrame(()=>{toast.style.transform='translateX(0)';});setTimeout(()=>{toast.style.transform='translateX(120%)';toast.addEventListener('transitionend',()=>toast.remove());},3000);}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
document.querySelectorAll('.quick-action, .user-btn, .menu-toggle, .notification-btn').forEach(btn => btn.addEventListener('click', (e) => {/* Ripple effect can be added here */}));
console.log('Class Management Dashboard initialized successfully!');

document.addEventListener('click', function(event) {
    const deleteButton = event.target.closest('.btn-delete');
    if (deleteButton) {
        if (confirm('Are you sure you want to delete this record?')) {
            showToast('Record deleted (simulation).', 'success');
            deleteButton.closest('tr').remove();
        }
    }
});
















